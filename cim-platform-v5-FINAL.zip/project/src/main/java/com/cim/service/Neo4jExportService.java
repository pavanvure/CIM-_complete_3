package com.cim.service;

import com.cim.model.mongo.CimObjectRecord;
import com.cim.model.mongo.Neo4jExportJob;
import com.cim.model.mongo.ExportRequest;
import com.cim.model.mongo.ExportRequest.ExportMode;
import com.cim.model.mongo.ExportRequest.VersionType;
import com.cim.repository.CimObjectRecordRepository;
import com.cim.repository.Neo4jExportJobRepository;
import com.cim.repository.ValidationJobRepository;
import com.cim.util.MapKeySanitizer;
import org.neo4j.driver.*;
import org.neo4j.driver.exceptions.Neo4jException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.*;

/**
 * Neo4j Export Service — v5
 *
 * Changes from previous version:
 *
 * REQ #1 — Index drop/rebuild removed.
 *           Indexes are maintained live. Heap tuning handles performance.
 *
 * REQ #2 — No :CIMNode or :CIMObject labels.
 *           Nodes have ONLY their specific cimType label (:ACLineSegment etc).
 *           Matches your existing Neo4j topology structure.
 *
 * REQ #3 — Three version types per export:
 *           FULL      → stored with version "{version}-0"
 *           SANITISED → stored with version "{version}-1" (default)
 *           RESILIENT → stored with version "{version}-2"
 *
 * REQ #4 — OrgId specific: export uses jobId orgId + req.orgId override.
 *
 * Performance: per-label constraints created upfront, batch=5000.
 */
@Service
public class Neo4jExportService {

    private static final Logger log = LoggerFactory.getLogger(Neo4jExportService.class);

    @Value("${cim.neo4j.export.batch-size:5000}")
    private int batchSize;

    private final Driver                    driver;
    private final MongoTemplate             mongo;
    private final CimObjectRecordRepository objectRepo;
    private final Neo4jExportJobRepository  exportRepo;
    private final ValidationJobRepository   jobRepo;

    // Tracks labels that already have a constraint this export run
    private final Set<String> constrainedLabels = new HashSet<>();

    private Neo4jExportExecutor executor;

    @org.springframework.beans.factory.annotation.Autowired
    public void setExecutor(Neo4jExportExecutor executor) { this.executor = executor; }

    public Neo4jExportService(Driver driver, MongoTemplate mongo,
                               CimObjectRecordRepository objectRepo,
                               Neo4jExportJobRepository exportRepo,
                               ValidationJobRepository jobRepo) {
        this.driver     = driver;
        this.mongo      = mongo;
        this.objectRepo = objectRepo;
        this.exportRepo = exportRepo;
        this.jobRepo    = jobRepo;
    }

    // ── Start export ──────────────────────────────────────────────────────

    /**
     * Starts a Neo4j export.
     *
     * SINGLE variant:   uses req.versionType + req.cimTypes
     * MULTI variant:    uses req.fullCimTypes + sanitisedCimTypes + resilientCimTypes
     *                   triggers three separate async export jobs
     *
     * Returns the first job created (or a summary job for multi-variant).
     */
    public Neo4jExportJob startExport(ExportRequest req) {
        String jobOrgId = jobRepo.findByJobId(req.getJobId())
                .map(j -> j.getOrgId() != null ? j.getOrgId() : "").orElse("");
        String orgId = (req.getOrgId() != null && !req.getOrgId().isBlank())
                       ? req.getOrgId().trim() : jobOrgId;

        String networkVersion = jobRepo.findByJobId(req.getJobId())
                .map(j -> j.getNetworkVersion() != null ? j.getNetworkVersion() : "")
                .orElse("");

        if (req.isMultiVariant()) {
            return startMultiVariantExport(req, networkVersion, orgId);
        }
        return startSingleExport(req, networkVersion, orgId,
                req.getVersionType(), req.getCimTypes());
    }

    /**
     * Triggers three separate export jobs — one per variant.
     * Each uses its own cimType list and version suffix.
     */
    private Neo4jExportJob startMultiVariantExport(ExportRequest req,
                                                    String networkVersion,
                                                    String orgId) {
        Neo4jExportJob firstJob = null;

        // FULL (-0)
        if (!req.getFullCimTypes().isEmpty()) {
            Neo4jExportJob j = startSingleExport(req, networkVersion, orgId,
                    ExportRequest.VersionType.FULL, req.getFullCimTypes());
            if (firstJob == null) firstJob = j;
            log.info("Multi-variant: FULL ({}-0) triggered — {} cimTypes",
                    networkVersion, req.getFullCimTypes().size());
        }

        // SANITISED (-1)
        if (!req.getSanitisedCimTypes().isEmpty()) {
            Neo4jExportJob j = startSingleExport(req, networkVersion, orgId,
                    ExportRequest.VersionType.SANITISED, req.getSanitisedCimTypes());
            if (firstJob == null) firstJob = j;
            log.info("Multi-variant: SANITISED ({}-1) triggered — {} cimTypes",
                    networkVersion, req.getSanitisedCimTypes().size());
        }

        // RESILIENT (-2)
        if (!req.getResilientCimTypes().isEmpty()) {
            Neo4jExportJob j = startSingleExport(req, networkVersion, orgId,
                    ExportRequest.VersionType.RESILIENT, req.getResilientCimTypes());
            if (firstJob == null) firstJob = j;
            log.info("Multi-variant: RESILIENT ({}-2) triggered — {} cimTypes",
                    networkVersion, req.getResilientCimTypes().size());
        }

        return firstJob;
    }

    private Neo4jExportJob startSingleExport(ExportRequest req,
                                              String networkVersion,
                                              String orgId,
                                              ExportRequest.VersionType vType,
                                              List<String> typesForVariant) {
        String exportId     = UUID.randomUUID().toString();
        String neo4jVersion = req.buildNeo4jVersion(networkVersion, vType);

        Neo4jExportJob job = new Neo4jExportJob(
                exportId, req.getJobId(), neo4jVersion, orgId,
                "CUSTOM_" + vType.name());
        exportRepo.save(job);

        // Build a single-variant request for the executor
        ExportRequest singleReq = new ExportRequest(
                req.getJobId(),
                ExportRequest.ExportMode.CUSTOM,
                typesForVariant,
                req.isClearFirst());
        singleReq.setVersionType(vType);
        singleReq.setOrgId(orgId);

        executor.runAsync(singleReq, job);
        return job;
    }

    // ── Called by executor on async thread ───────────────────────────────

    public void runExport(ExportRequest req, Neo4jExportJob job) {
        try {
            job.setStatus("RUNNING");
            exportRepo.save(job);
            long start = System.currentTimeMillis();
            constrainedLabels.clear();

            // Resolve effective orgId
            String orgId = job.getOrgId();
            // neo4jVersion already has suffix (e.g. "DB140-1")
            String neo4jVersion = job.getNetworkVersion();

            // Use CREATE (not MERGE) when clearFirst=true — 10-20x faster
            // Safe because we just deleted all nodes for this version+orgId
            this.useBulkCreate = req.isClearFirst();

            if (req.isClearFirst()) {
                clearExistingNodes(neo4jVersion, orgId);
            }

            // Create per-label constraints upfront
            // Needed for MERGE mode; also used for post-import query performance
            createConstraintsUpfront(req);

            int[] counts = twoPassExport(req, job, neo4jVersion, orgId);

            job.setStatus("DONE");
            job.setNodesExported(counts[0]);
            job.setRelsExported(counts[1]);
            job.setCompletedAt(Instant.now());
            job.setProcessingMs(System.currentTimeMillis() - start);
            exportRepo.save(job);

            log.info("Export DONE: mode={} version={} orgId={} nodes={} rels={} in {}",
                    req.getMode(), neo4jVersion, orgId, counts[0], counts[1],
                    com.cim.model.mongo.StageTimings.format(
                            System.currentTimeMillis() - start));

        } catch (Exception e) {
            log.error("Export FAILED: {}", e.getMessage(), e);
            job.setStatus("FAILED");
            job.setErrorMessage(e.getMessage());
            job.setCompletedAt(Instant.now());
            exportRepo.save(job);
        }
    }

    // ── Two-pass export ───────────────────────────────────────────────────

    private int[] twoPassExport(ExportRequest req, Neo4jExportJob job,
                                  String neo4jVersion, String orgId) {
        int totalNodes = 0, totalRels = 0;
        long total = mongo.count(new Query(buildCriteria(req)), "cim_objects");
        log.info("Pass 1 — {} nodes batch={} version={} orgId={}",
                total, batchSize, neo4jVersion, orgId);

        long start = System.currentTimeMillis();
        String lastId = null;
        int page = 0;

        // ── Pass 1: Nodes ─────────────────────────────────────────────────
        while (true) {
            List<CimObjectRecord> batch = fetchPage(req, lastId);
            if (batch.isEmpty()) break;

            totalNodes += writeNodes(batch, neo4jVersion, orgId);
            lastId = batch.get(batch.size() - 1).getId();
            page++;

            if (page % 20 == 0) {
                long el   = System.currentTimeMillis() - start;
                long rate = el > 0 ? totalNodes * 1000L / el : 0;
                long eta  = rate > 0 ? (total - totalNodes) / rate / 60 : -1;
                log.info("Pass 1: page={} nodes={}/{} rate={}/s eta={}min",
                        page, totalNodes, total, rate, eta);
                job.setNodesExported(totalNodes);
                exportRepo.save(job);
            }
        }
        log.info("Pass 1 DONE — {} nodes in {}",
                totalNodes,
                com.cim.model.mongo.StageTimings.format(
                        System.currentTimeMillis() - start));

        // ── Pass 2: Relationships ─────────────────────────────────────────
        log.info("Pass 2 — relationships");
        start = System.currentTimeMillis();
        lastId = null; page = 0;

        while (true) {
            List<CimObjectRecord> batch = fetchPage(req, lastId);
            if (batch.isEmpty()) break;

            totalRels += writeRelationships(batch, neo4jVersion, orgId);
            lastId = batch.get(batch.size() - 1).getId();
            page++;

            if (page % 20 == 0) {
                log.info("Pass 2: page={} rels={}", page, totalRels);
                job.setRelsExported(totalRels);
                exportRepo.save(job);
            }
        }
        log.info("Pass 2 DONE — {} rels in {}",
                totalRels,
                com.cim.model.mongo.StageTimings.format(
                        System.currentTimeMillis() - start));

        return new int[]{totalNodes, totalRels};
    }

    // ── Write nodes — single cimType label only (REQ #2) ─────────────────

    private boolean useBulkCreate = false; // set true when clearFirst=true

    /**
     * Write nodes using CREATE (clearFirst) or MERGE (incremental).
     *
     * CREATE mode (clearFirst=true):
     *   - No duplicate check needed — nodes were just deleted
     *   - No index lookup per node — pure append write
     *   - 10-20x faster than MERGE: O(1) vs O(log n) per node
     *   - No MERGE scan degradation as node count grows
     *
     * MERGE mode (incremental):
     *   - Safe when existing nodes may be present
     *   - Uses per-label constraint for O(log n) lookup
     *   - Slower but correct for partial re-exports
     */
    private int writeNodes(List<CimObjectRecord> records,
                            String neo4jVersion, String orgId) {
        if (records.isEmpty()) return 0;

        Map<String, List<Map<String, Object>>> byLabel = new LinkedHashMap<>();
        for (CimObjectRecord rec : records) {
            String label = sanitizeLabel(rec.getCimType());
            byLabel.computeIfAbsent(label, k -> new ArrayList<>())
                   .add(buildNodeProps(rec, neo4jVersion, orgId));
        }

        int written = 0;
        try (Session s = driver.session()) {
            for (Map.Entry<String, List<Map<String, Object>>> e : byLabel.entrySet()) {
                String label = e.getKey();
                List<Map<String, Object>> nodeBatch = e.getValue();
                String cypher;

                if (useBulkCreate) {
                    // CREATE — pure append, no lookup, no index maintenance during write
                    // :CIMNode is a shared routing label added to ALL nodes.
                    // This enables ONE index (CIMNode.nodeKey) used by Pass 2 MATCH.
                    // Without it, MATCH (src {nodeKey:...}) scans all 953K nodes = slow.
                    // Users still query by specific label (:ACLineSegment etc).
                    cypher = "UNWIND $batch AS p " +
                             "CREATE (n:" + label + ":CIMNode) SET n = p";
                } else {
                    // MERGE — idempotent, uses per-label constraint
                    ensureLabelConstraint(s, label);
                    cypher = "UNWIND $batch AS p " +
                             "MERGE (n:" + label + ":CIMNode {nodeKey: p.nodeKey}) " +
                             "SET n += p";
                }

                final String fc = cypher;
                final List<Map<String, Object>> fb = nodeBatch;
                try {
                    s.writeTransaction(tx -> {
                        tx.run(fc, Values.parameters("batch", fb));
                        return null;
                    });
                    written += nodeBatch.size();
                } catch (Neo4jException ex) {
                    log.warn("Node write failed {}: {}", label, ex.getMessage());
                }
            }
        } catch (Exception e) {
            log.warn("Session error writeNodes: {}", e.getMessage());
        }
        return written;
    }

    // ── Build node properties — version type variant handling (REQ #3) ────

    private Map<String, Object> buildNodeProps(CimObjectRecord rec,
                                                String neo4jVersion,
                                                String orgId) {
        Map<String, Object> p = new LinkedHashMap<>();
        String r = rec.getRdfId() != null ? rec.getRdfId() : "";
        String o = orgId         != null ? orgId           : "";

        // nodeKey uses neo4jVersion which already has suffix (e.g. "DB140-1")
        p.put("nodeKey",  r + "|" + neo4jVersion + "|" + o);
        p.put("mrid",     rec.getMrid()    != null ? rec.getMrid()    : r);
        p.put("rdfId",    r);
        p.put("name",     rec.getName()    != null ? rec.getName()    : "");
        p.put("cimType",  rec.getCimType() != null ? rec.getCimType() : "Unknown");
        p.put("version",  neo4jVersion);   // "DB140-0", "DB140-1", or "DB140-2"
        p.put("orgId",    o);
        p.put("category", rec.getCategory() != null ? rec.getCategory() : "");
        p.put("uri",      rec.getSourceFile() != null ? rec.getSourceFile() : "");

        // All variants use same attribute storage — differentiation is by
        // which CIM types are selected, not how attributes are stored.
        // Store CIM attributes with non-blank values (skip custom namespaces).
        if (rec.getAttributes() != null) {
            MapKeySanitizer.decodeKeys(rec.getAttributes()).forEach((k, v) -> {
                if (k != null && v != null && !v.isBlank() && !k.contains(":")) {
                    p.put(k, v);
                }
            });
        }
        return p;
    }

    // ── Write relationships ───────────────────────────────────────────────

    private int writeRelationships(List<CimObjectRecord> records,
                                    String neo4jVersion, String orgId) {
        if (records.isEmpty()) return 0;

        Map<String, List<Map<String, Object>>> byRelType = new LinkedHashMap<>();
        for (CimObjectRecord rec : records) {
            if (rec.getResolvedRefIds() == null || rec.getResolvedRefIds().isEmpty()) continue;
            String src = rec.getRdfId() != null ? rec.getRdfId() : "";
            String o   = orgId != null ? orgId : "";

            MapKeySanitizer.decodeKeys(rec.getResolvedRefIds())
                    .forEach((key, tgt) -> {
                        Map<String, Object> r = new LinkedHashMap<>();
                        // Use neo4jVersion (with suffix) for nodeKey matching
                        r.put("srcKey",  src + "|" + neo4jVersion + "|" + o);
                        r.put("tgtKey",  tgt + "|" + neo4jVersion + "|" + o);
                        r.put("version", neo4jVersion);
                        r.put("orgId",   o);
                        String relType = "`" + key.replace("`", "") + "`";
                        byRelType.computeIfAbsent(relType, k -> new ArrayList<>()).add(r);
                    });
        }

        int written = 0;
        try (Session s = driver.session()) {
            for (Map.Entry<String, List<Map<String, Object>>> e : byRelType.entrySet()) {
                String relType = e.getKey();
                List<Map<String, Object>> relBatch = e.getValue();
                // :CIMNode label + cim_node_nodekey index = O(log n) MATCH
                // Without label: full scan of all 953K nodes per relationship
                // With :CIMNode + index: index lookup, ~1ms per batch
                String cypher =
                    "UNWIND $batch AS r " +
                    "MATCH (src:CIMNode {nodeKey: r.srcKey}) " +
                    "MATCH (tgt:CIMNode {nodeKey: r.tgtKey}) " +
                    "MERGE (src)-[:" + relType +
                    " {version: r.version, orgId: r.orgId}]->(tgt)";
                final String fc = cypher;
                final List<Map<String, Object>> fb = relBatch;
                try {
                    s.writeTransaction(tx -> {
                        tx.run(fc, Values.parameters("batch", fb));
                        return null;
                    });
                    written += relBatch.size();
                } catch (Neo4jException ex) {
                    log.warn("Rel write failed {}: {}", relType, ex.getMessage());
                }
            }
        } catch (Exception e) {
            log.warn("Session error writeRelationships: {}", e.getMessage());
        }
        return written;
    }

    // ── Constraint creation (upfront, per label) ──────────────────────────

    private void createConstraintsUpfront(ExportRequest req) {
        if (constrainedLabels.size() > 0) return;
        log.info("Creating constraints and indexes...");
        long start = System.currentTimeMillis();

        // Create indexes on :CIMNode label upfront
        // cim_node_nodekey  → used by Pass 2 MATCH  (CRITICAL for performance)
        // cim_node_version  → used by version-filtered queries and clearExistingNodes
        // cim_node_orgid    → used by org-filtered queries
        String[][] sharedIndexes = {
            {"cim_node_nodekey",
             "CREATE INDEX cim_node_nodekey IF NOT EXISTS FOR (n:CIMNode) ON (n.nodeKey)"},
            {"cim_node_version",
             "CREATE INDEX cim_node_version IF NOT EXISTS FOR (n:CIMNode) ON (n.version)"},
            {"cim_node_orgid",
             "CREATE INDEX cim_node_orgid IF NOT EXISTS FOR (n:CIMNode) ON (n.orgId)"},
            {"cim_node_mrid",
             "CREATE INDEX cim_node_mrid IF NOT EXISTS FOR (n:CIMNode) ON (n.mrid)"},
        };
        for (String[] idx : sharedIndexes) {
            try (Session s = driver.session()) {
                s.run(idx[1]);
                log.debug("Index ensured: {}", idx[0]);
            } catch (Exception e) {
                log.debug("Index note {}: {}", idx[0], e.getMessage());
            }
        }
        log.info("CIMNode indexes ready — Pass 2 MATCH will use cim_node_nodekey");

        org.springframework.data.mongodb.core.aggregation.Aggregation agg =
            org.springframework.data.mongodb.core.aggregation.Aggregation.newAggregation(
                org.springframework.data.mongodb.core.aggregation.Aggregation
                        .match(buildCriteria(req)),
                org.springframework.data.mongodb.core.aggregation.Aggregation
                        .group("cimType")
            );

        List<org.bson.Document> results = mongo.aggregate(
                agg, "cim_objects", org.bson.Document.class).getMappedResults();

        int created = 0;
        for (org.bson.Document doc : results) {
            Object ct = doc.get("_id");
            if (ct == null) continue;
            String label = sanitizeLabel(ct.toString());
            if (constrainedLabels.contains(label)) continue;
            try (Session s = driver.session()) {
                s.run("CREATE CONSTRAINT " + label + "_nodekey IF NOT EXISTS " +
                      "ON (n:" + label + ") ASSERT n.nodeKey IS UNIQUE");
                constrainedLabels.add(label);
                created++;
            } catch (Exception e) {
                constrainedLabels.add(label);
            }
        }
        log.info("Constraints ready: {} labels in {}",
                constrainedLabels.size(),
                com.cim.model.mongo.StageTimings.format(
                        System.currentTimeMillis() - start));
    }

    private void ensureLabelConstraint(Session s, String label) {
        if (constrainedLabels.contains(label)) return;
        try {
            s.run("CREATE CONSTRAINT " + label + "_nodekey IF NOT EXISTS " +
                  "ON (n:" + label + ") ASSERT n.nodeKey IS UNIQUE");
            constrainedLabels.add(label);
        } catch (Exception e) {
            constrainedLabels.add(label);
        }
    }

    // ── Clear existing nodes (batched, version+orgId scoped) ─────────────

    private void clearExistingNodes(String neo4jVersion, String orgId) {
        log.info("Clearing nodes version={} orgId={}", neo4jVersion, orgId);
        long total = 0;

        // Two-query delete handles both old nodes (no :CIMNode) and new nodes (:CIMNode)
        // Query 1: new nodes — uses :CIMNode index for fast delete (O(log n))
        // Query 2: old nodes — label-less fallback for legacy data without :CIMNode
        // Both run in batches to avoid large transaction timeouts

        // Pass A: delete new-format nodes with :CIMNode label (fast, index-backed)
        while (true) {
            try (Session s = driver.session()) {
                Result r = s.writeTransaction(tx -> tx.run(
                    "MATCH (n:CIMNode {version: $v, orgId: $o}) " +
                    "WITH n LIMIT 1000 DETACH DELETE n RETURN count(n) AS d",
                    Values.parameters("v", neo4jVersion, "o", orgId)));
                long d = r.single().get("d").asLong();
                total += d;
                if (d == 0) break;
            } catch (Exception e) { log.warn("Clear pass A: {}", e.getMessage()); break; }
        }

        // Pass B: delete old-format nodes WITHOUT :CIMNode label (legacy migration)
        // These exist if the data was exported before :CIMNode was introduced
        while (true) {
            try (Session s = driver.session()) {
                Result r = s.writeTransaction(tx -> tx.run(
                    "MATCH (n {version: $v, orgId: $o}) " +
                    "WHERE NOT n:CIMNode " +
                    "WITH n LIMIT 1000 DETACH DELETE n RETURN count(n) AS d",
                    Values.parameters("v", neo4jVersion, "o", orgId)));
                long d = r.single().get("d").asLong();
                total += d;
                if (d == 0) break;
            } catch (Exception e) { log.warn("Clear pass B: {}", e.getMessage()); break; }
        }

        if (total > 0)
            log.info("Cleared {} nodes (version={} orgId={})", total, neo4jVersion, orgId);
        else
            log.info("No existing nodes found for version={} orgId={}", neo4jVersion, orgId);
    }

    // ── Cursor pagination ─────────────────────────────────────────────────

    private List<CimObjectRecord> fetchPage(ExportRequest req, String lastId) {
        Criteria criteria = buildCriteria(req);
        if (lastId != null && !lastId.isBlank()) {
            criteria = new Criteria().andOperator(
                    criteria,
                    Criteria.where("_id").gt(
                            new org.bson.types.ObjectId(lastId)));
        }
        return mongo.find(
                new Query(criteria)
                        .limit(batchSize)
                        .with(Sort.by(Sort.Direction.ASC, "_id")),
                CimObjectRecord.class, "cim_objects");
    }

    private Criteria buildCriteria(ExportRequest req) {
        String jobId = req.getJobId();

        // CUSTOM with cimTypes list — used by all multi-variant exports
        if (req.getMode() == ExportMode.CUSTOM
                && req.getCimTypes() != null && !req.getCimTypes().isEmpty()) {
            return Criteria.where("jobId").is(jobId)
                    .and("cimType").in(req.getCimTypes());
        }

        if (req.getMode() == ExportMode.PHYSICAL_ONLY) {
            return Criteria.where("jobId").is(jobId).and("category").is("PHYSICAL");
        }
        if (req.getMode() == ExportMode.REQUIRED_ONLY) {
            return Criteria.where("jobId").is(jobId).and("isRequired").is(true);
        }
        if (req.getMode() == ExportMode.TOPOLOGY) {
            List<String> logical = Arrays.asList(
                    "Terminal","ConnectivityNode","TopologicalNode","TopologicalIsland");
            return new Criteria().orOperator(
                    Criteria.where("jobId").is(jobId).and("category").is("PHYSICAL"),
                    Criteria.where("jobId").is(jobId).and("cimType").in(logical));
        }
        // ALL
        return Criteria.where("jobId").is(jobId);
    }

    // ── Label sanitizer ───────────────────────────────────────────────────

    private String sanitizeLabel(String t) {
        if (t == null || t.isBlank()) return "Unknown";
        return t.replaceAll("[^A-Za-z0-9_]", "_");
    }

    // ── Cleanup legacy labels ─────────────────────────────────────────────

    public long removeLegacyLabels() {
        long total = 0;
        for (String label : Arrays.asList("CIMObject", "CIMNode")) {
            while (true) {
                try (Session s = driver.session()) {
                    String cypher = "MATCH (n:" + label + ") WITH n LIMIT 1000 " +
                                    "REMOVE n:" + label + " RETURN count(n) AS r";
                    Result r = s.writeTransaction(tx -> tx.run(cypher));
                    long removed = r.single().get("r").asLong();
                    total += removed;
                    if (removed == 0) break;
                    log.info("Removed :{} from {} nodes", label, removed);
                } catch (Exception e) { break; }
            }
        }
        log.info("Legacy label cleanup: {} nodes updated", total);
        return total;
    }

    // ── Migration — add :CIMNode to existing nodes ───────────────────────

    /**
     * Adds :CIMNode label to all existing nodes that don't have it yet.
     * Run this ONCE after deploying the :CIMNode fix.
     *
     * This is needed for:
     *   1. Pass 2 MATCH to find existing nodes via index
     *   2. clearExistingNodes() to delete them efficiently
     *   3. Version/orgId queries using CIMNode indexes
     *
     * Runs in batches of 5000 to avoid transaction timeouts.
     * Safe to run multiple times — idempotent (WHERE NOT n:CIMNode).
     */
    public long migrateAddCimNodeLabel() {
        log.info("Migration: adding :CIMNode label to existing nodes...");
        long total = 0;
        while (true) {
            try (Session s = driver.session()) {
                Result r = s.writeTransaction(tx -> tx.run(
                    "MATCH (n) WHERE NOT n:CIMNode AND n.nodeKey IS NOT NULL " +
                    "WITH n LIMIT 5000 SET n:CIMNode RETURN count(n) AS updated"));
                long updated = r.single().get("updated").asLong();
                total += updated;
                if (updated == 0) break;
                log.info("Migration progress: {} nodes labelled so far", total);
            } catch (Exception e) {
                log.warn("Migration batch error: {}", e.getMessage());
                break;
            }
        }
        log.info("Migration complete: {} nodes now have :CIMNode label", total);
        return total;
    }

    // ── Status ────────────────────────────────────────────────────────────

    public Optional<Neo4jExportJob> getExportStatus(String exportId) {
        return exportRepo.findByExportId(exportId);
    }

    public List<Neo4jExportJob> getRecentExports() {
        return exportRepo.findTop10ByOrderByStartedAtDesc();
    }
}
