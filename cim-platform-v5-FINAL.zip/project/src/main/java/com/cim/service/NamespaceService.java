package com.cim.service;

import com.cim.model.mongo.NamespaceConfig;
import com.cim.repository.NamespaceConfigRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * Namespace Configuration Service
 *
 * CACHE STRATEGY — Load on job start, clear on job end.
 *
 * WHY:
 *   isEnabled() and shouldValidatePath() are called once per attribute
 *   during import parsing. A 3.4M object file has ~34M attribute calls.
 *   Without cache: 34M MongoDB queries = 9+ hours.
 *   With cache:    34M HashMap lookups  = milliseconds.
 *
 * HOW:
 *   1. ImportService calls loadForJob(jobId) at the START of each import.
 *      Cache is populated fresh from MongoDB at that moment.
 *   2. ImportService uses isEnabled()/shouldValidatePath() throughout parsing.
 *   3. ImportService calls clearAfterJob(jobId) when import completes or fails.
 *      Cache is emptied — no stale data persists.
 *
 * CLUSTER BEHAVIOUR:
 *   Each node loads its own fresh cache per job.
 *   No shared state between nodes — fully independent.
 *   Node A's import uses Node A's cache (loaded fresh from MongoDB).
 *   Node B's import uses Node B's cache (loaded fresh from MongoDB).
 *   No coordination, no Change Streams, no TTL needed.
 *
 * CONCURRENT IMPORTS:
 *   Each job gets its own snapshot keyed by jobId.
 *   Two simultaneous imports on the same node use independent snapshots.
 */
@Service
public class NamespaceService {

    private static final Logger log = LoggerFactory.getLogger(NamespaceService.class);

    private final NamespaceConfigRepository repo;

    /**
     * Per-job cache: jobId → (prefix → NamespaceConfig)
     *
     * Key: jobId (UUID) — each import job has its own isolated snapshot.
     * Value: HashMap of prefix → config, loaded fresh from MongoDB at job start.
     *
     * Lifecycle:
     *   loadForJob(jobId)  → creates entry
     *   clearAfterJob(jobId) → removes entry
     */
    private final java.util.concurrent.ConcurrentHashMap<String, Map<String, NamespaceConfig>>
            jobCaches = new java.util.concurrent.ConcurrentHashMap<>();

    public NamespaceService(NamespaceConfigRepository repo) {
        this.repo = repo;
    }

    // ── Startup defaults ──────────────────────────────────────────────────

    @EventListener(ApplicationReadyEvent.class)
    public void initDefaults() {
        if (!repo.existsByPrefix("cim")) {
            repo.save(new NamespaceConfig(
                    "cim",
                    "http://iec.ch/TC57/CIM100#",
                    true, true,
                    "IEC CIM standard namespace — path validation applied"));
            log.info("Default 'cim' namespace created");
        }
        log.info("Namespace service ready — {} configs in DB", repo.count());
    }

    // ── Job lifecycle — called by ImportService ───────────────────────────

    /**
     * Load namespace configs for a specific import job.
     * Called ONCE at the START of each import job.
     *
     * Queries MongoDB fresh — picks up any namespace changes
     * made before this import started.
     *
     * @param jobId the import job UUID
     */
    public void loadForJob(String jobId) {
        Map<String, NamespaceConfig> snapshot = new HashMap<>();
        repo.findAll().forEach(c ->
                snapshot.put(normalizePrefix(c.getPrefix()), c));
        jobCaches.put(jobId, snapshot);
        log.info("Namespace cache loaded for job={}: {} configs", jobId, snapshot.size());
    }

    /**
     * Clear namespace cache for a completed job.
     * Called at the END of each import job (success or failure).
     * Prevents stale data accumulating in memory.
     *
     * @param jobId the import job UUID
     */
    public void clearAfterJob(String jobId) {
        Map<String, NamespaceConfig> removed = jobCaches.remove(jobId);
        if (removed != null) {
            log.info("Namespace cache cleared for job={} ({} configs freed)",
                    jobId, removed.size());
        }
    }

    // ── HOT PATH — called ~34M times during 3.4M object import ───────────

    /**
     * Is this namespace enabled for attribute storage?
     *
     * HOT PATH — O(1) HashMap lookup per call.
     * Uses job-specific cache loaded at job start.
     * Falls back to MongoDB if no job cache (e.g. during startup validation).
     *
     * @param jobId    the current import job
     * @param prefix   namespace prefix e.g. "cim", "caiso", "spc"
     */
    public boolean isEnabled(String jobId, String prefix) {
        Map<String, NamespaceConfig> cache = jobCaches.get(jobId);
        if (cache != null) {
            NamespaceConfig c = cache.get(normalizePrefix(prefix));
            return c != null && c.isEnabled();
        }
        // Fallback: direct DB query (only if cache not loaded — shouldn't happen)
        log.warn("No namespace cache for job={} — falling back to DB query", jobId);
        return repo.findByPrefix(normalizePrefix(prefix))
                .map(NamespaceConfig::isEnabled)
                .orElse(false);
    }

    /**
     * Should path validation run for this namespace?
     * HOT PATH — O(1) HashMap lookup.
     */
    public boolean shouldValidatePath(String jobId, String prefix) {
        Map<String, NamespaceConfig> cache = jobCaches.get(jobId);
        if (cache != null) {
            NamespaceConfig c = cache.get(normalizePrefix(prefix));
            return c != null && c.isEnabled() && c.isValidatePath();
        }
        return repo.findByPrefix(normalizePrefix(prefix))
                .map(c -> c.isEnabled() && c.isValidatePath())
                .orElse(false);
    }

    /**
     * Extract namespace prefix from an attribute tag.
     * "caiso:emsFlag"         → "caiso"
     * "ACLineSegment.r"       → "cim"
     * "IdentifiedObject.name" → "cim"
     */
    public String extractPrefix(String tag) {
        if (tag == null) return "cim";
        int i = tag.indexOf(':');
        return i > 0 ? tag.substring(0, i) : "cim";
    }

    // ── CRUD — REST API endpoints ─────────────────────────────────────────

    public List<NamespaceConfig> getAll()     { return repo.findAll(); }
    public List<NamespaceConfig> getEnabled() { return repo.findByEnabled(true); }

    public Optional<NamespaceConfig> findByPrefix(String prefix) {
        return repo.findByPrefix(normalizePrefix(prefix));
    }

    public NamespaceConfig create(NamespaceConfig config, String createdBy) {
        String prefix = normalizePrefix(config.getPrefix());
        if (repo.existsByPrefix(prefix))
            throw new IllegalArgumentException(
                    "Namespace prefix '" + prefix + "' already exists.");
        config.setPrefix(prefix);
        config.setCreatedBy(createdBy);
        config.setCreatedAt(Instant.now());
        config.setUpdatedAt(Instant.now());
        NamespaceConfig saved = repo.save(config);
        log.info("Namespace created: {} enabled={} validatePath={}",
                prefix, saved.isEnabled(), saved.isValidatePath());
        return saved;
    }

    public NamespaceConfig update(String prefix, boolean enabled, boolean validatePath) {
        String p = normalizePrefix(prefix);
        NamespaceConfig config = repo.findByPrefix(p)
                .orElseThrow(() -> new IllegalArgumentException(
                        "Namespace '" + p + "' not found."));
        config.setEnabled(enabled);
        config.setValidatePath(validatePath);
        config.setUpdatedAt(Instant.now());
        NamespaceConfig saved = repo.save(config);
        log.info("Namespace updated: {} enabled={} validatePath={}", p, enabled, validatePath);
        return saved;
    }

    public void delete(String prefix) {
        String p = normalizePrefix(prefix);
        repo.findByPrefix(p).ifPresent(c -> {
            repo.delete(c);
            log.info("Namespace deleted: {}", p);
        });
    }

    private String normalizePrefix(String p) {
        return p == null ? "" : p.toLowerCase().trim();
    }
}
