package com.cim.service;

import com.cim.model.mongo.CimObjectRecord;
import com.cim.model.mongo.ExportRequest;
import com.cim.model.mongo.RawCimObject;
import com.cim.repository.CimObjectRecordRepository;
import com.cim.repository.RawCimObjectRepository;
import com.cim.repository.ValidationJobRepository;
import com.cim.util.MapKeySanitizer;
import com.cim.validation.registry.CIMHierarchyRegistry;
import com.cim.validation.registry.PathValidationResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Revalidation Service — Enhancement 2
 *
 * When namespace configs change (e.g. enabling caiso namespace after import),
 * previously stored cim_objects have stale/missing attributes.
 *
 * This service re-processes raw_objects → updates cim_objects with fresh
 * namespace filtering and path validation → optionally triggers Neo4j re-export.
 *
 * FLOW:
 *   PUT /admin/namespaces/{id}/enable
 *     → NamespaceController calls RevalidationService.revalidateJob(jobId, orgId)
 *
 *   RevalidationService:
 *     1. Load fresh namespace config for this org
 *     2. Iterate raw_objects in batches (cursor pagination)
 *     3. For each raw object: re-apply namespace filtering + path validation
 *     4. Update cim_objects (SET attributes, pathIssues) — upsert by jobId+rdfId
 *     5. If triggerExport=true: start Neo4j export with stored config
 */
@Service
public class RevalidationService {

    private static final Logger log = LoggerFactory.getLogger(RevalidationService.class);
    private static final int BATCH = 500;

    private final RawCimObjectRepository     rawRepo;
    private final CimObjectRecordRepository  cimRepo;
    private final ValidationJobRepository    jobRepo;
    private final MongoTemplate              mongo;
    private final NamespaceService           namespaceService;
    private final CIMHierarchyRegistry       registry;
    private final Neo4jExportService         neo4jExportService;
    private final Neo4jExportExecutor        neo4jExportExecutor;

    public RevalidationService(RawCimObjectRepository rawRepo,
                                CimObjectRecordRepository cimRepo,
                                ValidationJobRepository jobRepo,
                                MongoTemplate mongo,
                                NamespaceService namespaceService,
                                CIMHierarchyRegistry registry,
                                Neo4jExportService neo4jExportService,
                                Neo4jExportExecutor neo4jExportExecutor) {
        this.rawRepo            = rawRepo;
        this.cimRepo            = cimRepo;
        this.jobRepo            = jobRepo;
        this.mongo              = mongo;
        this.namespaceService   = namespaceService;
        this.registry           = registry;
        this.neo4jExportService = neo4jExportService;
        this.neo4jExportExecutor= neo4jExportExecutor;
    }

    // ── Public API ────────────────────────────────────────────────────────

    /**
     * Result returned immediately to client (async processing continues).
     */
    public static class RevalidationResult {
        public final String  revalidationId;
        public final String  jobId;
        public final String  orgId;
        public final boolean triggerExport;
        public final String  status;

        public RevalidationResult(String revalidationId, String jobId,
                                   String orgId, boolean triggerExport) {
            this.revalidationId = revalidationId;
            this.jobId          = jobId;
            this.orgId          = orgId;
            this.triggerExport  = triggerExport;
            this.status         = "RUNNING";
        }
    }

    /**
     * Start async revalidation for a job.
     * Returns immediately — client polls /admin/revalidation/{id} for status.
     *
     * @param jobId         import job to revalidate
     * @param orgId         organisation (determines which namespace configs apply)
     * @param triggerExport if true, trigger Neo4j re-export after revalidation
     * @param exportRequest optional specific export config; null = use stored auto-export config
     */
    public RevalidationResult startRevalidation(String jobId, String orgId,
                                                 boolean triggerExport,
                                                 ExportRequest exportRequest) {
        String revalidationId = UUID.randomUUID().toString();
        RevalidationResult result =
                new RevalidationResult(revalidationId, jobId, orgId, triggerExport);

        // Store status in MongoDB
        org.bson.Document statusDoc = new org.bson.Document()
                .append("revalidationId", revalidationId)
                .append("jobId", jobId)
                .append("orgId", orgId)
                .append("triggerExport", triggerExport)
                .append("status", "RUNNING")
                .append("startedAt", Instant.now().toString())
                .append("objectsProcessed", 0L)
                .append("objectsUpdated", 0L);
        mongo.insert(statusDoc, "revalidation_jobs");

        runAsync(revalidationId, jobId, orgId, triggerExport, exportRequest);
        return result;
    }

    public Optional<org.bson.Document> getStatus(String revalidationId) {
        return Optional.ofNullable(mongo.findOne(
                new Query(Criteria.where("revalidationId").is(revalidationId)),
                org.bson.Document.class, "revalidation_jobs"));
    }

    // ── Async processing ──────────────────────────────────────────────────

    @Async
    public CompletableFuture<Void> runAsync(String revalidationId, String jobId,
                                             String orgId, boolean triggerExport,
                                             ExportRequest exportRequest) {
        long processed = 0, updated = 0;
        try {
            log.info("Revalidation started: id={} job={} orgId={}", revalidationId, jobId, orgId);

            // Load fresh namespace config for this org
            namespaceService.loadForJob(revalidationId, orgId);

            // Cursor pagination through raw_objects
            String lastId = null;
            while (true) {
                Criteria criteria = Criteria.where("jobId").is(jobId);
                if (lastId != null)
                    criteria = new Criteria().andOperator(criteria,
                            Criteria.where("_id").gt(new org.bson.types.ObjectId(lastId)));

                List<RawCimObject> batch = mongo.find(
                        new Query(criteria)
                                .limit(BATCH)
                                .with(org.springframework.data.domain.Sort.by(
                                        org.springframework.data.domain.Sort.Direction.ASC, "_id")),
                        RawCimObject.class, "raw_objects");

                if (batch.isEmpty()) break;

                List<CimObjectRecord> updates = new ArrayList<>();
                for (RawCimObject raw : batch) {
                    CimObjectRecord updated_rec = reprocessObject(raw, revalidationId, orgId);
                    if (updated_rec != null) {
                        updates.add(updated_rec);
                        updated++;
                    }
                    processed++;
                    lastId = raw.getId();
                }

                // Bulk upsert updated cim_objects
                if (!updates.isEmpty()) bulkUpsert(updates, jobId);

                // Update progress
                if (processed % 5000 == 0) {
                    updateStatus(revalidationId, "RUNNING", processed, updated, null);
                    log.info("Revalidation progress: id={} processed={} updated={}",
                            revalidationId, processed, updated);
                }
            }

            namespaceService.clearAfterJob(revalidationId);

            // Mark done
            updateStatus(revalidationId, "DONE", processed, updated, null);
            log.info("Revalidation DONE: id={} processed={} updated={}", revalidationId, processed, updated);

            // Enhancement 2: trigger Neo4j export if requested
            if (triggerExport) {
                triggerNeo4jExport(jobId, orgId, exportRequest);
            }

        } catch (Exception e) {
            log.error("Revalidation FAILED: id={} error={}", revalidationId, e.getMessage(), e);
            namespaceService.clearAfterJob(revalidationId);
            updateStatus(revalidationId, "FAILED", processed, updated, e.getMessage());
        }
        return CompletableFuture.completedFuture(null);
    }

    // ── Re-process single object ──────────────────────────────────────────

    /**
     * Re-applies namespace filtering + path validation to a raw object.
     * Returns an updated CimObjectRecord (does NOT save — caller bulk-saves).
     */
    private CimObjectRecord reprocessObject(RawCimObject raw,
                                              String jobId, String orgId) {
        // Find existing cim_objects record
        CimObjectRecord existing = mongo.findOne(
                new Query(Criteria.where("jobId").is(raw.getJobId())
                        .and("rdfId").is(raw.getRdfId())),
                CimObjectRecord.class, "cim_objects");

        if (existing == null) {
            // Object was filtered out entirely — create new record
            existing = new CimObjectRecord();
            existing.setJobId(raw.getJobId());
            existing.setRdfId(raw.getRdfId());
            existing.setMrid(raw.getMrid());
            existing.setCimType(raw.getCimType());
            existing.setName(raw.getName());
            existing.setOrgId(raw.getOrgId());
            existing.setVersion(raw.getVersion());
            existing.setSourceFormat(raw.getSourceFormat());
            existing.setSourceFile(raw.getSourceFile());

            // Set category and isRequired from registry
            String category = registry.getCategory(raw.getCimType());
            existing.setCategory(category != null ? category : "UNKNOWN");
            existing.setRequired("PHYSICAL".equals(category));
        }

        // Re-apply namespace filtering + path validation from raw attributes
        Map<String, String> newAttributes = new LinkedHashMap<>();
        List<Map<String, String>> newPathIssues = new ArrayList<>();

        if (raw.getRawAttributes() != null) {
            Map<String, String> decoded = MapKeySanitizer.decodeKeys(raw.getRawAttributes());
            for (Map.Entry<String, String> e : decoded.entrySet()) {
                String tag    = e.getKey();
                String value  = e.getValue();
                String prefix = namespaceService.extractPrefix(tag);

                if (namespaceService.isEnabled(jobId, prefix)) {
                    // Namespace enabled — store attribute
                    if (value != null && !value.isBlank()) {
                        newAttributes.put(MapKeySanitizer.encode(tag), value);
                    }
                    // Path validation
                    if (namespaceService.shouldValidatePath(jobId, prefix)) {
                        PathValidationResult pvr =
                                registry.validateAttributePath(raw.getCimType(), tag);
                        if (pvr != null && pvr.isInvalid()) {
                            Map<String, String> issue = new LinkedHashMap<>();
                            issue.put("status", pvr.name());
                            issue.put("tag", tag);
                            issue.put("explanation", pvr.getExplanation(raw.getCimType(), tag));
                            newPathIssues.add(issue);
                        }
                    }
                } else {
                    // Namespace disabled — log UNKNOWN_NAMESPACE
                    Map<String, String> issue = new LinkedHashMap<>();
                    issue.put("status", "UNKNOWN_NAMESPACE");
                    issue.put("tag", tag);
                    issue.put("explanation",
                            "Namespace '" + prefix + "' not enabled for org '"
                            + orgId + "'. Enable via PUT /api/cim/admin/namespaces/{id}/enable");
                    newPathIssues.add(issue);
                }
            }
        }

        existing.setAttributes(newAttributes);
        existing.setPathIssues(newPathIssues);
        return existing;
    }

    // ── Bulk upsert updated records ───────────────────────────────────────

    private void bulkUpsert(List<CimObjectRecord> records, String jobId) {
        List<org.springframework.data.mongodb.core.BulkOperations.OperationType> ops =
                new ArrayList<>();

        org.springframework.data.mongodb.core.BulkOperations bulk =
                mongo.bulkOps(
                        org.springframework.data.mongodb.core.BulkOperations.BulkMode.UNORDERED,
                        "cim_objects");

        for (CimObjectRecord rec : records) {
            org.springframework.data.mongodb.core.query.Query q =
                    new org.springframework.data.mongodb.core.query.Query(
                            Criteria.where("jobId").is(rec.getJobId())
                                    .and("rdfId").is(rec.getRdfId()));
            org.springframework.data.mongodb.core.query.Update u =
                    new org.springframework.data.mongodb.core.query.Update()
                            .set("attributes", rec.getAttributes())
                            .set("pathIssues", rec.getPathIssues());
            if (rec.getCategory() != null) u.set("category", rec.getCategory());
            bulk.upsert(q, u);
        }

        try {
            bulk.execute();
        } catch (Exception e) {
            log.warn("Bulk upsert error: {}", e.getMessage());
        }
    }

    // ── Trigger Neo4j export after revalidation ───────────────────────────

    private void triggerNeo4jExport(String jobId, String orgId,
                                     ExportRequest exportRequest) {
        try {
            ExportRequest req = exportRequest != null ? exportRequest : new ExportRequest();
            req.setJobId(jobId);
            if (req.getOrgId() == null) req.setOrgId(orgId);
            if (req.getVersionType() == null)
                req.setVersionType(ExportRequest.VersionType.SANITISED);
            req.setClearFirst(true); // always clear — we just updated cim_objects

            neo4jExportService.startExport(req);
            log.info("Neo4j export triggered after revalidation: job={} orgId={}", jobId, orgId);
        } catch (Exception e) {
            log.warn("Neo4j export trigger failed after revalidation: {}", e.getMessage());
        }
    }

    // ── Status update helper ──────────────────────────────────────────────

    private void updateStatus(String revalidationId, String status,
                               long processed, long updated, String error) {
        org.springframework.data.mongodb.core.query.Update u =
                new org.springframework.data.mongodb.core.query.Update()
                        .set("status", status)
                        .set("objectsProcessed", processed)
                        .set("objectsUpdated", updated)
                        .set("completedAt", Instant.now().toString());
        if (error != null) u.set("errorMessage", error);
        mongo.updateFirst(
                new Query(Criteria.where("revalidationId").is(revalidationId)),
                u, "revalidation_jobs");
    }
}
