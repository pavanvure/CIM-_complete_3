package com.cim.model.mongo;

/**
 * Request body for POST /api/cim/admin/revalidate
 * REQ 2: Replaces Map<String,Object> for clear Swagger UI rendering.
 */
public class RevalidationRequest {

    /** Import job ID to revalidate. Required unless using orgId+version alias. */
    private String jobId;

    /** Organisation ID — determines which namespace configs apply. Required. */
    private String orgId;

    /**
     * If true: trigger Neo4j re-export after revalidation completes.
     * Uses the stored auto-export config for this orgId.
     * All configured variants (FULL/SANITISED/RATIONALISED/CUSTOM) are triggered.
     */
    private boolean triggerExport = false;

    /**
     * Optional specific export config to use after revalidation.
     * If null and triggerExport=true: uses stored auto-export config.
     *
     * Example:
     * {
     *   "mode":        "FROM_CONFIG",
     *   "configId":    "6820f398...",
     *   "clearFirst":  true
     * }
     */
    private ExportRequest exportRequest;

    public RevalidationRequest() {}

    public String        getJobId()                      { return jobId; }
    public void          setJobId(String v)              { this.jobId = v; }
    public String        getOrgId()                      { return orgId; }
    public void          setOrgId(String v)              { this.orgId = v; }
    public boolean       isTriggerExport()               { return triggerExport; }
    public void          setTriggerExport(boolean v)     { this.triggerExport = v; }
    public ExportRequest getExportRequest()              { return exportRequest; }
    public void          setExportRequest(ExportRequest v){ this.exportRequest = v; }
}
