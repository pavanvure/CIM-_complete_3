package com.cim.streaming;

import com.cim.model.cim.CIMObject;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.function.Consumer;

/**
 * Milsoft CSV File Parser — Streaming, O(1) memory.
 *
 * MILSOFT FILE FORMAT:
 *   Milsoft WindMil exports use a multi-section CSV format.
 *   Each section starts with a header line declaring the equipment type:
 *
 *   [Line]                          ← section header = CIM type
 *   ID,Name,FromNode,ToNode,R1,X1,B1,Length
 *   1001,BONN_NBON_4230A,N100,N200,0.111,1.031,0.0000,45000
 *   1002,WEST_EAST_1380,N300,N400,0.092,0.881,0.0000,32000
 *
 *   [Switch]
 *   ID,Name,Node1,Node2,NormalOpen,Type
 *   2001,BKR-WEST,N100,N150,0,Breaker
 *   2002,DSC-EAST,N200,N250,1,Disconnector
 *
 *   [Transformer]
 *   ID,Name,Node1,Node2,kVA,PrimaryKV,SecondaryKV
 *   3001,XFMR-MAIN,N100,N110,10000,230,115
 *
 * MILSOFT → CIM MAPPING:
 *   [Line]        → ACLineSegment
 *   [Switch]      → Breaker / Disconnector / Fuse (from Type column)
 *   [Transformer] → PowerTransformer
 *   [Bus]         → ConnectivityNode
 *   [Load]        → EnergyConsumer
 *   [Generator]   → SynchronousMachine
 *   [Capacitor]   → LinearShuntCompensator
 *   [Regulator]   → TapChanger
 *   [Substation]  → Substation
 *
 * ATTRIBUTE MAPPING:
 *   Column names → stored as {CimType}.{attributeName}
 *   e.g. Line.R1 → ACLineSegment.r
 *        Switch.NormalOpen → Switch.normalOpen
 *
 * rdfId: generated as "_milsoft_{sectionType}_{ID}"
 */
@Service
public class StreamingMilsoftCsvParser {

    private static final Logger log =
            LoggerFactory.getLogger(StreamingMilsoftCsvParser.class);

    // ── Milsoft section name → CIM type mapping ───────────────────────────
    private static final Map<String, String> SECTION_TO_CIM = new LinkedHashMap<>();
    static {
        SECTION_TO_CIM.put("LINE",         "ACLineSegment");
        SECTION_TO_CIM.put("SWITCH",       "Switch");       // refined per-row by Type col
        SECTION_TO_CIM.put("TRANSFORMER",  "PowerTransformer");
        SECTION_TO_CIM.put("BUS",          "ConnectivityNode");
        SECTION_TO_CIM.put("LOAD",         "EnergyConsumer");
        SECTION_TO_CIM.put("GENERATOR",    "SynchronousMachine");
        SECTION_TO_CIM.put("CAPACITOR",    "LinearShuntCompensator");
        SECTION_TO_CIM.put("REGULATOR",    "TapChanger");
        SECTION_TO_CIM.put("SUBSTATION",   "Substation");
        SECTION_TO_CIM.put("FEEDER",       "Line");
        SECTION_TO_CIM.put("NODE",         "ConnectivityNode");
        SECTION_TO_CIM.put("SOURCEBUS",    "TopologicalNode");
        SECTION_TO_CIM.put("AREA",         "SubGeographicalRegion");
        SECTION_TO_CIM.put("ZONE",         "GeographicalRegion");
    }

    // ── Milsoft column → CIM attribute mapping per section ───────────────
    // Format: column name (uppercase) → CIM attribute name
    private static final Map<String, Map<String, String>> COL_MAP = new HashMap<>();
    static {
        // LINE section
        Map<String, String> line = new LinkedHashMap<>();
        line.put("R1",       "ACLineSegment.r");
        line.put("X1",       "ACLineSegment.x");
        line.put("B1",       "ACLineSegment.bch");
        line.put("R0",       "ACLineSegment.r0");
        line.put("X0",       "ACLineSegment.x0");
        line.put("LENGTH",   "Conductor.length");
        line.put("RATING",   "CurrentLimit.value");
        line.put("FROMNODE", "ref:ACLineSegment.fromNode");  // ref: prefix = reference
        line.put("TONODE",   "ref:ACLineSegment.toNode");
        COL_MAP.put("LINE", line);

        // SWITCH section
        Map<String, String> sw = new LinkedHashMap<>();
        sw.put("NORMALOPEN", "Switch.normalOpen");
        sw.put("TYPE",       "milsoft:switchType");          // drives cimType refinement
        sw.put("NODE1",      "ref:Switch.node1");
        sw.put("NODE2",      "ref:Switch.node2");
        sw.put("RATING",     "CurrentLimit.value");
        COL_MAP.put("SWITCH", sw);

        // TRANSFORMER section
        Map<String, String> xfmr = new LinkedHashMap<>();
        xfmr.put("KVA",         "PowerTransformer.ratedS");
        xfmr.put("PRIMARYKV",   "TransformerEnd.ratedU");
        xfmr.put("SECONDARYKV", "milsoft:secondaryKV");
        xfmr.put("IMPEDANCEP",  "TransformerMeshImpedance.r");
        xfmr.put("NODE1",       "ref:PowerTransformer.node1");
        xfmr.put("NODE2",       "ref:PowerTransformer.node2");
        xfmr.put("RATING",      "CurrentLimit.value");
        COL_MAP.put("TRANSFORMER", xfmr);

        // BUS/NODE section
        Map<String, String> bus = new LinkedHashMap<>();
        bus.put("BASEKV",    "BaseVoltage.nominalVoltage");
        bus.put("VOLTAGE",   "SvVoltage.v");
        bus.put("ANGLE",     "SvVoltage.angle");
        bus.put("TYPE",      "milsoft:busType");
        COL_MAP.put("BUS", bus);
        COL_MAP.put("NODE", bus);

        // LOAD section
        Map<String, String> load = new LinkedHashMap<>();
        load.put("KW",      "EnergyConsumer.p");
        load.put("KVAR",    "EnergyConsumer.q");
        load.put("NODE",    "ref:EnergyConsumer.node");
        load.put("PHASES",  "ConductingEquipment.phases");
        COL_MAP.put("LOAD", load);

        // GENERATOR section
        Map<String, String> gen = new LinkedHashMap<>();
        gen.put("KW",       "SynchronousMachine.p");
        gen.put("KVAR",     "SynchronousMachine.q");
        gen.put("KVA",      "SynchronousMachine.ratedS");
        gen.put("NODE",     "ref:SynchronousMachine.node");
        gen.put("TYPE",     "milsoft:generatorType");
        COL_MAP.put("GENERATOR", gen);

        // CAPACITOR section
        Map<String, String> cap = new LinkedHashMap<>();
        cap.put("KVAR",     "LinearShuntCompensator.bPerSection");
        cap.put("NODE",     "ref:LinearShuntCompensator.node");
        cap.put("PHASES",   "ConductingEquipment.phases");
        COL_MAP.put("CAPACITOR", cap);

        // SUBSTATION section
        Map<String, String> sub = new LinkedHashMap<>();
        sub.put("REGION",   "ref:Substation.region");
        sub.put("AREA",     "ref:Substation.area");
        COL_MAP.put("SUBSTATION", sub);
    }

    // ── Switch type refinement ───────────────────────────────────────────
    private static final Map<String, String> SWITCH_TYPE_MAP = new HashMap<>();
    static {
        SWITCH_TYPE_MAP.put("BREAKER",      "Breaker");
        SWITCH_TYPE_MAP.put("DISCONNECTOR", "Disconnector");
        SWITCH_TYPE_MAP.put("FUSE",         "Fuse");
        SWITCH_TYPE_MAP.put("RECLOSER",     "Recloser");
        SWITCH_TYPE_MAP.put("SECTIONALIZER","LoadBreakSwitch");
        SWITCH_TYPE_MAP.put("JUMPER",       "Jumper");
    }

    // ── Main parse method ─────────────────────────────────────────────────

    /**
     * Stream-parse a Milsoft CSV file.
     * Calls onObject once per CIM object found.
     * Memory: O(1) — processes one row at a time.
     *
     * @param in        input stream of the .csv file
     * @param fileName  original filename (stored on each object)
     * @param onObject  callback — called for each parsed CIMObject
     */
    public void stream(InputStream in, String fileName,
                        Consumer<CIMObject> onObject) throws Exception {
        long total = 0;
        String currentSection = null;
        List<String> headers   = null;
        Map<String, String> colMapping = null;

        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(in, StandardCharsets.UTF_8))) {

            String line;
            int lineNum = 0;

            while ((line = reader.readLine()) != null) {
                lineNum++;
                line = line.trim();

                // Skip empty lines and comment lines
                if (line.isEmpty() || line.startsWith("//")
                        || line.startsWith("#") || line.startsWith(";")) {
                    continue;
                }

                // Section header: [SectionName]
                if (line.startsWith("[") && line.endsWith("]")) {
                    currentSection = line.substring(1, line.length() - 1)
                            .trim().toUpperCase();
                    headers   = null;
                    colMapping = COL_MAP.getOrDefault(currentSection, new HashMap<>());
                    log.debug("CSV section: [{}]", currentSection);
                    continue;
                }

                if (currentSection == null) continue;

                // First non-blank line after section header = column headers
                if (headers == null) {
                    headers = parseHeaderLine(line);
                    continue;
                }

                // Data row — parse into CIMObject
                try {
                    CIMObject obj = parseRow(line, headers, colMapping,
                            currentSection, fileName, lineNum);
                    if (obj != null) {
                        onObject.accept(obj);
                        total++;
                    }
                } catch (Exception e) {
                    log.warn("CSV parse error line {}: {} — {}", lineNum, line, e.getMessage());
                }
            }
        }

        log.info("Milsoft CSV parse complete: {} objects from {}", total, fileName);
    }

    // ── Parse single data row ─────────────────────────────────────────────

    private CIMObject parseRow(String line, List<String> headers,
                                Map<String, String> colMapping,
                                String section, String fileName,
                                int lineNum) {
        // Simple CSV split (handles basic quoting)
        List<String> values = splitCsvLine(line);
        if (values.isEmpty()) return null;

        // Need at least ID and Name columns
        int idIdx   = indexOfIgnoreCase(headers, "ID");
        int nameIdx = indexOfIgnoreCase(headers, "NAME");

        String rowId   = idIdx   >= 0 && idIdx   < values.size() ? values.get(idIdx).trim()   : String.valueOf(lineNum);
        String rowName = nameIdx >= 0 && nameIdx < values.size() ? values.get(nameIdx).trim() : "";

        // Determine CIM type
        String cimType = SECTION_TO_CIM.getOrDefault(section, "milsoft:" + section);

        CIMObject obj = new CIMObject();
        obj.setRdfId("_milsoft_" + section.toLowerCase() + "_" + rowId);
        obj.setMrid(obj.getRdfId());
        obj.setName(rowName);
        obj.setCimType(cimType);
        obj.setSourceFile(fileName);
        obj.setSourceFormat("MILSOFT_CSV");

        Map<String, String> attributes = new LinkedHashMap<>();
        Map<String, String> references = new LinkedHashMap<>();

        // Process each column
        for (int i = 0; i < headers.size() && i < values.size(); i++) {
            String colUpper = headers.get(i).toUpperCase();
            String value    = values.get(i).trim();

            if (value.isEmpty()) continue;

            // Look up CIM mapping for this column
            String cimAttr = colMapping.get(colUpper);

            if (cimAttr == null) {
                // No explicit mapping — store as milsoft: vendor attribute
                attributes.put("milsoft:" + colUpper.toLowerCase(), value);
                continue;
            }

            if (cimAttr.startsWith("ref:")) {
                // Reference attribute — store in references map
                String refKey = cimAttr.substring(4);
                // Milsoft IDs → generate rdfId
                references.put(refKey, "_milsoft_node_" + value);

            } else if (cimAttr.equals("milsoft:switchType")) {
                // Refine the switch cimType based on Type column
                String refined = SWITCH_TYPE_MAP.get(value.toUpperCase());
                if (refined != null) obj.setCimType(refined);
                attributes.put(cimAttr, value);

            } else if (cimAttr.equals("Switch.normalOpen")) {
                // Normalise: 0/false → "false", 1/true → "true"
                String normalized = ("1".equals(value) || "true".equalsIgnoreCase(value))
                        ? "true" : "false";
                attributes.put(cimAttr, normalized);

            } else {
                attributes.put(cimAttr, value);
            }
        }

        obj.setAttributes(attributes);
        obj.setReferences(references);
        return obj;
    }

    // ── Column header parsing ─────────────────────────────────────────────

    private List<String> parseHeaderLine(String line) {
        List<String> headers = new ArrayList<>();
        for (String h : splitCsvLine(line)) {
            headers.add(h.trim().toUpperCase());
        }
        return headers;
    }

    // ── CSV line splitter (handles quoted fields) ─────────────────────────

    private List<String> splitCsvLine(String line) {
        List<String> result = new ArrayList<>();
        StringBuilder sb    = new StringBuilder();
        boolean inQuotes    = false;
        for (int i = 0; i < line.length(); i++) {
            char ch = line.charAt(i);
            if (ch == '"') {
                inQuotes = !inQuotes;
            } else if (ch == ',' && !inQuotes) {
                result.add(sb.toString());
                sb.setLength(0);
            } else {
                sb.append(ch);
            }
        }
        result.add(sb.toString());
        return result;
    }

    private int indexOfIgnoreCase(List<String> list, String target) {
        for (int i = 0; i < list.size(); i++) {
            if (target.equalsIgnoreCase(list.get(i))) return i;
        }
        return -1;
    }

    /**
     * Returns true if the given file content looks like a Milsoft CSV.
     * Used by ImportService for auto-detection.
     */
    public boolean canParse(String firstLine) {
        if (firstLine == null) return false;
        String upper = firstLine.trim().toUpperCase();
        return upper.startsWith("[") && SECTION_TO_CIM.containsKey(
                upper.replaceAll("[\\[\\]]", ""));
    }
}
