package com.cim.service;

import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import java.util.concurrent.CompletableFuture;

/**
 * Revalidation Async Executor — separate Spring bean.
 *
 * WHY THIS EXISTS:
 *   Spring @Async works via proxy — Spring wraps the bean in a proxy
 *   that intercepts calls and routes them to a thread pool.
 *
 *   PROBLEM with self-call:
 *     RevalidationService.startRevalidation() calls this.runAsync()
 *     → "this" is the raw object, NOT the Spring proxy
 *     → Spring proxy is bypassed
 *     → @Async has NO effect — runs synchronously on the HTTP thread
 *     → Client waits until revalidation finishes (hours)
 *
 *   FIX — separate bean:
 *     RevalidationService          (Spring proxy A)
 *       → calls RevalidationExecutor.runAsync()
 *            (Spring proxy B intercepts the call)
 *            → routed to @Async thread pool
 *            → HTTP thread returns immediately ✅
 *
 *   This is the same pattern used by Neo4jExportExecutor.
 */
@Component
public class RevalidationExecutor {

    private final RevalidationService revalidationService;

    public RevalidationExecutor(RevalidationService revalidationService) {
        this.revalidationService = revalidationService;
    }

    /**
     * Runs revalidation on a Spring-managed async thread.
     * Called by RevalidationService.startRevalidation() — never call directly.
     */
    @Async
    public CompletableFuture<Void> runAsync(String revalidationId, String jobId,
                                             String orgId, boolean triggerExport,
                                             com.cim.model.mongo.ExportRequest exportRequest) {
        return revalidationService.runAsync(
                revalidationId, jobId, orgId, triggerExport, exportRequest);
    }
}
