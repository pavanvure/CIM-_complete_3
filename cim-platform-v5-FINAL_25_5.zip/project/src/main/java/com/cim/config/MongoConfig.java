package com.cim.config;

import com.mongodb.MongoClientSettings;
import org.bson.UuidRepresentation;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.MongoDatabaseFactory;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.convert.DefaultMongoTypeMapper;
import org.springframework.data.mongodb.core.convert.MappingMongoConverter;
import org.springframework.data.mongodb.core.convert.MongoCustomConversions;
import org.springframework.data.mongodb.core.mapping.MongoMappingContext;

/**
 * MongoDB configuration.
 * Key setting: dot replacement for attribute map keys.
 * CIM attributes use dots (ACLineSegment.r) — MongoDB rejects dots in keys.
 * Replace with U+FF0E (FULLWIDTH FULL STOP) as a safe substitute.
 */
@Configuration
public class MongoConfig {

    @Bean
    public MongoTemplate mongoTemplate(MongoDatabaseFactory factory,
                                        MappingMongoConverter converter) {
        // Remove _class field from documents
        converter.setTypeMapper(new DefaultMongoTypeMapper(null));
        // Replace dots in map keys with U+FF0E
        converter.setMapKeyDotReplacement("\uFF0E");
        return new MongoTemplate(factory, converter);
    }
}
