package com.cim.model.mongo;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.CompoundIndex;
import org.springframework.data.mongodb.core.index.CompoundIndexes;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Raw CIM object — stores file content EXACTLY as parsed.
 *
 * PURPOSE:
 *   Audit trail and re-processing source. Contains everything from the
 *   original file without any filtering, validation, or transformation.
 *
 * DIFFERENCE FROM cim_objects:
 *   raw_objects              cim_objects
 *   ─────────────────────    ─────────────────────────────────────
 *   All attributes stored    Only enabled-namespace attrs stored
 *   All namespaces stored    Disabled namespaces → pathIssues
 *   No path validation        pathIssues populated
 *   No reference resolution   resolvedRefIds populated
 *   Empty values kept         Empty values filtered (SANITISED)
 *   Stored immediately        Stored after validation
 *
 * LINK TO cim_objects:
 *   Same jobId + rdfId identifies the same object across both collections.
 *
 * FORMAT AGNOSTIC:
 *   Works for RDF/XML, JSON-LD, and Milsoft CSV.
 *   sourceFormat field records which parser produced this record.
 */
@Document(collection = "raw_objects")
@CompoundIndexes({
    @CompoundIndex(name = "raw_idx_jobid",       def = "{'jobId':1}"),
    @CompoundIndex(name = "raw_idx_jobid_rdfid",  def = "{'jobId':1,'rdfId':1}"),
    @CompoundIndex(name = "raw_idx_jobid_type",   def = "{'jobId':1,'cimType':1}"),
    @CompoundIndex(name = "raw_idx_jobid_orgid",  def = "{'jobId':1,'orgId':1}"),
})
public class RawCimObject {

    @Id
    private String id;

    /** Links to ValidationJob and cim_objects — same jobId for same import */
    private String jobId;

    /** rdf:ID or rdf:about — matches cim_objects.rdfId for same object */
    private String rdfId;

    /** IdentifiedObject.mRID — global unique identifier */
    private String mrid;

    /** CIM class name e.g. ACLineSegment, Terminal, Breaker */
    private String cimType;

    /** IdentifiedObject.name */
    private String name;

    /** Organisation identifier */
    private String orgId;

    /** Network version label e.g. DB140, 2024-Q1 */
    private String version;

    /** RDF_XML, JSON_LD, MILSOFT_CSV */
    private String sourceFormat;

    /** Original filename */
    private String sourceFile;

    /**
     * ALL attributes exactly as parsed from the file.
     * No namespace filtering. No empty-value removal.
     * Includes cim:, caiso:, spc:, and any vendor namespace attributes.
     *
     * Key encoding: dot replaced by U+FF0E for MongoDB compatibility.
     * e.g. "ACLineSegment\uFF0Er" → value "0.11109"
     *      "caiso\uFF0EemsFlag"   → value "true"
     */
    private Map<String, String> rawAttributes = new LinkedHashMap<>();

    /**
     * ALL rdf:resource references exactly as parsed.
     * e.g. "ConductingEquipment\uFF0EBaseVoltage" → "_bv-uuid"
     *      "Equipment\uFF0EEquipmentContainer"    → "_line-uuid"
     */
    private Map<String, String> rawReferences = new LinkedHashMap<>();

    /** Timestamp when this record was inserted */
    private Instant createdAt;

    public RawCimObject() {
        this.createdAt = Instant.now();
    }

    // ── Getters / Setters ─────────────────────────────────────────────────

    public String getId()                              { return id; }
    public String getJobId()                           { return jobId; }
    public void   setJobId(String v)                   { this.jobId = v; }
    public String getRdfId()                           { return rdfId; }
    public void   setRdfId(String v)                   { this.rdfId = v; }
    public String getMrid()                            { return mrid; }
    public void   setMrid(String v)                    { this.mrid = v; }
    public String getCimType()                         { return cimType; }
    public void   setCimType(String v)                 { this.cimType = v; }
    public String getName()                            { return name; }
    public void   setName(String v)                    { this.name = v; }
    public String getOrgId()                           { return orgId; }
    public void   setOrgId(String v)                   { this.orgId = v; }
    public String getVersion()                         { return version; }
    public void   setVersion(String v)                 { this.version = v; }
    public String getSourceFormat()                    { return sourceFormat; }
    public void   setSourceFormat(String v)            { this.sourceFormat = v; }
    public String getSourceFile()                      { return sourceFile; }
    public void   setSourceFile(String v)              { this.sourceFile = v; }
    public Map<String,String> getRawAttributes()       { return rawAttributes; }
    public void   setRawAttributes(Map<String,String> v){ this.rawAttributes = v != null ? v : new LinkedHashMap<>(); }
    public Map<String,String> getRawReferences()       { return rawReferences; }
    public void   setRawReferences(Map<String,String> v){ this.rawReferences = v != null ? v : new LinkedHashMap<>(); }
    public Instant getCreatedAt()                      { return createdAt; }
}
