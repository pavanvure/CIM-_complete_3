package com.cim.streaming;

import com.fasterxml.jackson.annotation.JsonInclude;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.Instant;
import java.util.concurrent.atomic.AtomicLong;

public class ProgressTracker {

    private static final Logger log = LoggerFactory.getLogger(ProgressTracker.class);

    public enum Stage {
        DETECTING_FORMAT, STREAMING_PARSE, RESOLVING_REFERENCES,
        PATH_VALIDATION, DONE, FAILED
    }

    private final String     jobId;
    private final int        logEvery;
    private       long       totalObjects = -1; // REQ #5: set from file estimate
    private final long       startMs = System.currentTimeMillis();
    private       Stage      stage   = Stage.DETECTING_FORMAT;
    private       String     detail;
    private       String     errorMessage;
    private       long       completedMs = -1;  // fixed when done/failed
    private final AtomicLong parsed  = new AtomicLong();
    private final AtomicLong saved   = new AtomicLong();

    public ProgressTracker(String jobId, int logEvery) {
        this.jobId    = jobId;
        this.logEvery = logEvery;
    }

    public void setStage(Stage s, String detail) {
        this.stage  = s;
        this.detail = detail;
        log.info("[Job {}] stage={} {}", jobId, s, detail != null ? detail : "");
    }

    /** REQ #5: set expected total for accurate percentSaved */
    public void setTotalObjects(long total) { this.totalObjects = total; }

    public void incrementParsed() {
        long v = parsed.incrementAndGet();
        if (v % logEvery == 0) logProgress();
    }

    public void incrementSaved(long n) { saved.addAndGet(n); }

    public void log(String msg) { log.info("[Job {}] {}", jobId, msg); }
    public void done() {
        stage = Stage.DONE;
        completedMs = System.currentTimeMillis() - startMs;
    }
    public void fail(String m) {
        stage = Stage.FAILED;
        errorMessage = m;
        completedMs = System.currentTimeMillis() - startMs;
    }

    public ProgressSnapshot snapshot() {
        // Use fixed completedMs when done — prevents elapsedMs growing after finish
        long el = completedMs >= 0
                ? completedMs
                : System.currentTimeMillis() - startMs;
        long p    = parsed.get(), s = saved.get();
        double r  = el > 0 ? p * 1000.0 / el : 0;

        // percentSaved calculation:
        //   If DONE or FAILED → always 100 (saved==parsed, estimate irrelevant)
        //   If running → use totalObjects estimate for smooth progress,
        //                but cap at 99 until actually done to avoid premature 100%
        int pct;
        if (stage == Stage.DONE || stage == Stage.FAILED) {
            pct = 100;  // always 100 when finished, regardless of estimate
        } else {
            long denominator = totalObjects > 0 ? totalObjects : Math.max(1, p);
            pct = (int) Math.min(99, s * 100L / denominator); // cap at 99 while running
        }
        String readable = com.cim.model.mongo.StageTimings.format(el);
        return new ProgressSnapshot(jobId, stage.name(),
                detail != null ? detail : "",
                p, s, el, readable, Math.round(r), pct,
                stage == Stage.DONE || stage == Stage.FAILED, errorMessage);
    }

    private void logProgress() {
        long el = System.currentTimeMillis() - startMs;
        log.info("[Job {}] stage={} parsed={} saved={} rate={}/s",
                jobId, stage, parsed.get(), saved.get(),
                el > 0 ? (int)(parsed.get()*1000.0/el) : 0);
    }

    private String formatMs(long ms) {
        long s=ms/1000, h=s/3600, m=(s%3600)/60, sec=s%60;
        if (h>0) return h+"h "+m+"m "+sec+"s";
        if (m>0) return m+"m "+sec+"s";
        return sec+"s";
    }

    public String  getJobId()   { return jobId; }
    public Stage   getStage()   { return stage; }
    public long    getParsed()  { return parsed.get(); }
    public long    getSaved()   { return saved.get(); }
    public boolean isDone()     { return stage == Stage.DONE; }
    public boolean isFailed()   { return stage == Stage.FAILED; }
}

@JsonInclude(JsonInclude.Include.NON_NULL)
class ProgressSnapshot {
    private final String  jobId,stage,stageDetail,elapsedFormatted,errorMessage;
    private final long    parsed,saved,elapsedMs,parseRatePerSec;
    private final int     percentSaved;
    private final boolean finished;

    ProgressSnapshot(String jobId,String stage,String stageDetail,
                      long parsed,long saved,long elapsedMs,
                      String elapsedFormatted,long rate,int pct,
                      boolean finished,String errorMessage) {
        this.jobId=jobId; this.stage=stage; this.stageDetail=stageDetail;
        this.parsed=parsed; this.saved=saved; this.elapsedMs=elapsedMs;
        this.elapsedFormatted=elapsedFormatted; this.parseRatePerSec=rate;
        this.percentSaved=pct; this.finished=finished; this.errorMessage=errorMessage;
    }

    public String  getJobId()            { return jobId; }
    public String  getStage()            { return stage; }
    public String  getStageDetail()      { return stageDetail; }
    public long    getParsed()           { return parsed; }
    public long    getSaved()            { return saved; }
    public long    getElapsedMs()        { return elapsedMs; }
    public String  getElapsedFormatted() { return elapsedFormatted; }
    public long    getParseRatePerSec()  { return parseRatePerSec; }
    public int     getPercentSaved()     { return percentSaved; }
    public boolean isFinished()          { return finished; }
    public String  getErrorMessage()     { return errorMessage; }
}
