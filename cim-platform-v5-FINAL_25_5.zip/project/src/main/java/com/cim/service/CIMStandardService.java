package com.cim.service;

import com.cim.model.mongo.CimClassDefinition;
import com.cim.repository.CimClassRepository;
import com.cim.validation.registry.CIMHierarchyRegistry;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.*;
import java.util.*;

@Service
public class CIMStandardService {

    private static final Logger log = LoggerFactory.getLogger(CIMStandardService.class);

    @Value("${cim.owl.file-path:}")  private String singlePath;
    @Value("${cim.owl.version:CIM17}") private String version;

    private final CimClassRepository   repo;
    private final CIMHierarchyRegistry registry;
    private final CIMOwlParser         parser;

    public CIMStandardService(CimClassRepository repo, CIMHierarchyRegistry registry,
                               CIMOwlParser parser) {
        this.repo = repo; this.registry = registry; this.parser = parser;
    }

    @EventListener(ApplicationReadyEvent.class)
    public void init() {
        if (repo.count() > 0) {
            registry.load(repo.findAll());
            log.info("Registry loaded from MongoDB: {} classes", registry.size());
            return;
        }
        if (singlePath != null && !singlePath.isBlank()) {
            try { loadSingle(singlePath, version); return; }
            catch (Exception e) { log.error("OWL load failed: {}", e.getMessage()); }
        }
        log.warn("CIM registry empty — upload OWL via POST /api/admin/cim/upload-owl");
    }

    /**
     * Result of an OWL load operation.
     * Java 11 compatible POJO — replaces Java 16 record syntax.
     */
    public static class LoadResult {
        private final String version;
        private final int    total;
        private final int    physical;
        private final int    logical;

        public LoadResult(String version, int total, int physical, int logical) {
            this.version  = version;
            this.total    = total;
            this.physical = physical;
            this.logical  = logical;
        }

        public String version()  { return version; }
        public int    total()    { return total; }
        public int    physical() { return physical; }
        public int    logical()  { return logical; }
    }

    public LoadResult uploadSingle(MultipartFile file, String v) throws Exception {
        List<CimClassDefinition> defs = parser.parse(file.getInputStream(), v,
                file.getOriginalFilename());
        return persist(defs, v);
    }

    public LoadResult uploadMultiple(List<MultipartFile> files, String v) throws Exception {
        Map<String, InputStream> streams = new LinkedHashMap<>();
        for (MultipartFile f : files) streams.put(f.getOriginalFilename(), f.getInputStream());
        List<CimClassDefinition> defs = parser.parseMultiple(streams, v);
        return persist(defs, v);
    }

    public LoadResult reload() throws Exception {
        if (singlePath != null && !singlePath.isBlank()) return loadSingle(singlePath, version);
        throw new IllegalStateException("No OWL path configured in application.yml");
    }

    private LoadResult loadSingle(String path, String v) throws Exception {
        File f = new File(path);
        if (!f.exists()) throw new FileNotFoundException("OWL not found: " + path);
        try (InputStream is = new BufferedInputStream(new FileInputStream(f), 65536)) {
            return persist(parser.parse(is, v, f.getName()), v);
        }
    }

    private LoadResult persist(List<CimClassDefinition> defs, String v) {
        repo.deleteAll();
        repo.saveAll(defs);
        registry.load(defs);
        long p = defs.stream().filter(d -> "PHYSICAL".equals(d.getCategory())).count();
        long l = defs.stream().filter(d -> "LOGICAL".equals(d.getCategory())).count();
        log.info("OWL persisted: {} total ({} PHYSICAL, {} LOGICAL)", defs.size(), p, l);
        return new LoadResult(v, defs.size(), (int)p, (int)l);
    }
}
