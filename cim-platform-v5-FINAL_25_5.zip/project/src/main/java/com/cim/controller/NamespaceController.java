package com.cim.controller;

import com.cim.model.mongo.NamespaceConfig;
import com.cim.service.NamespaceService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * Namespace Configuration REST API (REQ #2, #3, #4)
 *
 * GET    /api/admin/namespaces              list all namespaces
 * POST   /api/admin/namespaces             add new namespace
 * PUT    /api/admin/namespaces/{prefix}    update namespace settings
 * DELETE /api/admin/namespaces/{prefix}    remove namespace
 * PUT    /api/admin/namespaces/{prefix}/enable   enable namespace
 * PUT    /api/admin/namespaces/{prefix}/disable  disable namespace
 * POST   /api/admin/namespaces/refresh     reload cache from DB
 *
 * Namespace behaviour:
 *   enabled=true,  validatePath=true  → store + CIM path validation (cim namespace)
 *   enabled=true,  validatePath=false → store as-is, no path check (caiso, spc)
 *   enabled=false                     → skip attributes, log UNKNOWN_NAMESPACE
 *
 * REQ #4 note: after updating namespaces, user can call:
 *   POST /api/jobs/{jobId}/revalidate-paths  → re-run path issues for a job
 *   POST /api/admin/neo4j/export             → re-export to Neo4j
 */
@RestController
@RequestMapping("/api/admin/namespaces")
@CrossOrigin(origins = "*")
public class NamespaceController {

    private final NamespaceService namespaceService;

    public NamespaceController(NamespaceService namespaceService) {
        this.namespaceService = namespaceService;
    }

    @GetMapping
    public ResponseEntity<?> listAll() {
        var all = namespaceService.getAll();
        return ResponseEntity.ok(Map.of(
            "total",      all.size(),
            "enabled",    all.stream().filter(NamespaceConfig::isEnabled).count(),
            "disabled",   all.stream().filter(n -> !n.isEnabled()).count(),
            "namespaces", all
        ));
    }

    /**
     * Add a new namespace.
     * Body: { "prefix":"caiso", "namespaceUri":"http://caiso.com/cim#",
     *         "enabled":true, "validatePath":false, "description":"CAISO custom" }
     */
    @PostMapping
    public ResponseEntity<?> addNamespace(
            @RequestBody NamespaceConfig config,
            @RequestHeader(value="X-User", defaultValue="system") String user) {
        try {
            NamespaceConfig saved = namespaceService.create(config, user);
            return ResponseEntity.ok(Map.of(
                "message",  "Namespace '" + saved.getPrefix() + "' added.",
                "namespace", saved,
                "note", saved.isEnabled()
                        ? "Attributes with prefix '" + saved.getPrefix()
                          + "' will be stored in future imports."
                        : "Namespace disabled. Attributes will be logged as UNKNOWN_NAMESPACE."
            ));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    /**
     * Update namespace settings.
     * Body: { "enabled":true, "validatePath":false }
     */
    @PutMapping("/{prefix}")
    public ResponseEntity<?> updateNamespace(
            @PathVariable String prefix,
            @RequestBody Map<String,Object> body) {
        try {
            boolean enabled      = Boolean.parseBoolean(
                    body.getOrDefault("enabled","true").toString());
            boolean validatePath = Boolean.parseBoolean(
                    body.getOrDefault("validatePath","false").toString());
            NamespaceConfig saved = namespaceService.update(prefix, enabled, validatePath);
            return ResponseEntity.ok(Map.of(
                "message",       "Namespace '" + prefix + "' updated.",
                "namespace",     saved,
                "note", "Re-import or call POST /api/jobs/{jobId}/revalidate-paths "
                      + "to apply changes to existing imported objects."
            ));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    @PutMapping("/{prefix}/enable")
    public ResponseEntity<?> enable(@PathVariable String prefix) {
        try {
            NamespaceConfig saved = namespaceService.update(prefix, true, false);
            return ResponseEntity.ok(Map.of(
                "message", "Namespace '" + prefix + "' enabled.",
                "note",    "Future imports will store attributes with this prefix."
            ));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    @PutMapping("/{prefix}/disable")
    public ResponseEntity<?> disable(@PathVariable String prefix) {
        try {
            NamespaceConfig saved = namespaceService.update(prefix, false, false);
            return ResponseEntity.ok(Map.of(
                "message", "Namespace '" + prefix + "' disabled.",
                "note",    "Future imports will log UNKNOWN_NAMESPACE for this prefix."
            ));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    @DeleteMapping("/{prefix}")
    public ResponseEntity<?> deleteNamespace(@PathVariable String prefix) {
        namespaceService.delete(prefix);
        return ResponseEntity.ok(Map.of(
            "message", "Namespace '" + prefix + "' removed.",
            "note",    "CIM default namespaces (cim,rdf,rdfs) will be re-created on restart."
        ));
    }

    @PostMapping("/refresh")
    public ResponseEntity<?> refresh() {
        namespaceService.refreshCache();
        return ResponseEntity.ok(Map.of(
            "message", "Namespace cache refreshed.",
            "total",    namespaceService.getAll().size()
        ));
    }
}
