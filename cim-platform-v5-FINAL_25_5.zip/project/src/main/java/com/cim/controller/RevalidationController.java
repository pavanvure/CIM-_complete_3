package com.cim.controller;

import com.cim.model.mongo.ExportRequest;
import com.cim.service.RevalidationService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * Revalidation REST API — Enhancement 2
 *
 * When namespace configs change, existing cim_objects have stale attributes.
 * These endpoints trigger re-processing of raw_objects → cim_objects
 * with the new namespace settings, and optionally re-export to Neo4j.
 *
 * POST /api/cim/admin/revalidate
 *   Start async revalidation for a job.
 *
 * GET /api/cim/admin/revalidate/{revalidationId}
 *   Poll revalidation status.
 */
@RestController
@RequestMapping("/api/cim/admin")
@CrossOrigin(origins = "*")
public class RevalidationController {

    private final RevalidationService revalidationService;

    public RevalidationController(RevalidationService revalidationService) {
        this.revalidationService = revalidationService;
    }

    /**
     * POST /api/cim/admin/revalidate
     *
     * Re-processes raw_objects → cim_objects with fresh namespace settings.
     * Use after enabling/disabling a namespace or changing validatePath.
     *
     * Body:
     * {
     *   "jobId":         "uuid",           required
     *   "orgId":         "CAISO",          required - determines which namespace configs apply
     *   "triggerExport": true,             optional - re-export to Neo4j after revalidation
     *   "exportRequest": {                 optional - specific export config
     *     "versionType": "SANITISED",
     *     "cimTypes":    ["ACLineSegment","Breaker","..."],
     *     "clearFirst":  true
     *   }
     * }
     *
     * Returns immediately with revalidationId.
     * Poll GET /api/cim/admin/revalidate/{id} for status.
     */
    @PostMapping("/revalidate")
    public ResponseEntity<?> startRevalidation(
            @RequestBody Map<String, Object> body) {

        String jobId = (String) body.get("jobId");
        String orgId = (String) body.getOrDefault("orgId", "");

        if (jobId == null || jobId.isBlank())
            return ResponseEntity.badRequest()
                    .body(Map.of("error", "jobId is required."));

        boolean triggerExport = Boolean.parseBoolean(
                body.getOrDefault("triggerExport", "false").toString());

        // Optional export request
        ExportRequest exportRequest = null;
        if (body.containsKey("exportRequest") && triggerExport) {
            @SuppressWarnings("unchecked")
            Map<String, Object> expMap = (Map<String, Object>) body.get("exportRequest");
            exportRequest = new ExportRequest();
            exportRequest.setJobId(jobId);
            if (expMap.containsKey("versionType")) {
                try {
                    exportRequest.setVersionType(ExportRequest.VersionType.valueOf(
                            expMap.get("versionType").toString().toUpperCase()));
                } catch (Exception e) {
                    exportRequest.setVersionType(ExportRequest.VersionType.SANITISED);
                }
            }
            if (expMap.containsKey("cimTypes")) {
                @SuppressWarnings("unchecked")
                java.util.List<String> types = (java.util.List<String>) expMap.get("cimTypes");
                exportRequest.setCimTypes(types);
                exportRequest.setMode(ExportRequest.ExportMode.CUSTOM);
            }
            if (expMap.containsKey("configId")) {
                exportRequest.setConfigId(expMap.get("configId").toString());
                exportRequest.setMode(ExportRequest.ExportMode.FROM_CONFIG);
            }
            exportRequest.setClearFirst(
                    Boolean.parseBoolean(
                            expMap.getOrDefault("clearFirst", "true").toString()));
        }

        RevalidationService.RevalidationResult result =
                revalidationService.startRevalidation(
                        jobId, orgId, triggerExport, exportRequest);

        return ResponseEntity.accepted().body(Map.of(
            "revalidationId", result.revalidationId,
            "jobId",          jobId,
            "orgId",          orgId,
            "triggerExport",  triggerExport,
            "status",         "RUNNING",
            "message",        "Revalidation started. Raw objects will be re-processed "
                            + "with current namespace settings for orgId=" + orgId,
            "links", Map.of(
                "status", "/api/cim/admin/revalidate/" + result.revalidationId
            )
        ));
    }

    /**
     * GET /api/cim/admin/revalidate/{revalidationId}
     * Poll revalidation status.
     */
    @GetMapping("/revalidate/{revalidationId}")
    public ResponseEntity<?> getStatus(@PathVariable String revalidationId) {
        return revalidationService.getStatus(revalidationId)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }
}
